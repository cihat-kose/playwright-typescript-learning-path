    function addToIG(ig) {
        if (navigator.joinAdInterestGroup) {
            try {
                navigator.joinAdInterestGroup(ig, 2592000000);
            } catch(e) {
                fetch('https://us.creativecdn.com/ig-membership' + '?ig='+ encodeURIComponent(ig.name) + '&err=' +  encodeURIComponent(e.toString().substring(0, 256))).catch(() => {});
            }
        }
    }

    addToIG({"owner":"https://f.creativecdn.com","name":"Ss52YF3IAd5cEVfrVcQ0","biddingLogicURL":"https://f.creativecdn.com/statics/buyer.js","biddingWasmHelperURL":"https://f.creativecdn.com/statics/buyer.wasm","trustedBiddingSignalsURL":"https://f.creativecdn.com/bidder/tbsweb/bids","trustedBiddingSignalsKeys":["v5_Spe5nvnHuFktQvxiwATWS8rza25HRX1VijbuXKoQDoW1-yATImswT9WRjni5gAXcVHT97eMsCukoszDCE9p03KF22ucY7oV3hwo8U_bZkac"],"ads":[],"adComponents":[],"priority":0.0,"executionMode":"compatibility","auctionServerRequestFlags":["omit-ads"],"updateURL":"https://f.creativecdn.com/update-ig?ntk=cd39L-LXzibcTkG5H2RIL19wnctbxlyXLi-bwyEuBnJxGBDSGcMcZ3es7-G-wts6212cOGAJaEW5KYlh54WwYLu9RRGyp1tvXEQrUZVVQrYoPehRbhevviQtKmjgRqT4","privateAggregationConfig":{"aggregationCoordinatorOrigin":"https://publickeyservice.msmt.gcp.privacysandboxservices.com"}});
